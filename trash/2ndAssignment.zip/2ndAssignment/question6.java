import java.util.HashSet;

public class question6 {
    public static void main(String[] args) {
        // get user input for lower and upper limits
        int lowerLimit = Integer.parseInt(System.console().readLine("Enter lower limit: "));
        int upperLimit = Integer.parseInt(System.console().readLine("Enter upper limit: "));

        // create a set to keep track of printed numbers
        HashSet<Integer> printedNumbers = new HashSet<>();

        // create two threads to print numbers
        Thread thread1 = new Thread(new PrintNumbers(lowerLimit, upperLimit/2, printedNumbers));
        Thread thread2 = new Thread(new PrintNumbers(upperLimit/2 + 1, upperLimit, printedNumbers));

        // start the threads
        thread1.start();
        thread2.start();
    }
}

class PrintNumbers implements Runnable {
    private int lowerLimit;
    private int upperLimit;
    private HashSet<Integer> printedNumbers;

    public PrintNumbers(int lowerLimit, int upperLimit, HashSet<Integer> printedNumbers) {
        this.lowerLimit = lowerLimit;
        this.upperLimit = upperLimit;
        this.printedNumbers = printedNumbers;
    }

    public void run() {
        for (int num = lowerLimit; num <= upperLimit; num++) {
            // check if number has already been printed
            if (!printedNumbers.contains(num)) {
                System.out.println(num);
                printedNumbers.add(num);
            }
        }
    }
}
