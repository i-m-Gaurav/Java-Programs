import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class question4 {
    

    public static void main(String[] args) {
        String str = "jdbc:mysql://localhost:3306/gaurav";
    Connection conn = null;
    Properties props = new Properties();
    props.put("user", "root");
    props.put("password", "0000");
        try  {
            conn = DriverManager.getConnection(str, props);
            if (conn != null) {
                System.out.println("Successful");
            }
            String getSalesProcedure = "{ call getResultSet(?, ?) }";
            CallableStatement stmt = conn.prepareCall(getSalesProcedure);

            int salesmanId = 1;
            stmt.setInt(1, salesmanId);
            stmt.registerOutParameter(2, java.sql.Types.VARCHAR);

            stmt.execute();

            String salesResult = stmt.getString(2);
            System.out.println("Sales for salesman with id " + salesmanId + ": " + salesResult);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
